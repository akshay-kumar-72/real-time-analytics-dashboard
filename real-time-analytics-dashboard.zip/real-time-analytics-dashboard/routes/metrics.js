const express = require('express');
const router = express.Router();
const Metric = require('../models/Metric');

router.post('/', async (req, res) => {
  const { type, value } = req.body;
  const metric = new Metric({ type, value });
  await metric.save();
  res.status(201).json(metric);
});

router.get('/', async (req, res) => {
  const metrics = await Metric.find().sort({ timestamp: -1 }).limit(20);
  res.json(metrics);
});

module.exports = router;
