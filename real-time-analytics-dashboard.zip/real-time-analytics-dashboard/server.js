const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');
const Metric = require('./models/Metric');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
  }
});

mongoose.connect('mongodb://127.0.0.1:27017/realtime_dashboard');

app.use(cors());
app.use(express.json());
app.use('/api/metrics', require('./routes/metrics'));
app.use(express.static('public'));

io.on('connection', socket => {
  console.log('New client connected');
  const interval = setInterval(async () => {
    const metrics = await Metric.find().sort({ timestamp: -1 }).limit(5);
    socket.emit('metrics', metrics);
  }, 2000);

  socket.on('disconnect', () => {
    clearInterval(interval);
    console.log('Client disconnected');
  });
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
