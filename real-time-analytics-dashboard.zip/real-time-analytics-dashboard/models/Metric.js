const mongoose = require('mongoose');

const MetricSchema = new mongoose.Schema({
  type: String,
  value: Number,
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Metric', MetricSchema);
